from flask import Flask,render_template,url_for,redirect,request
app = Flask(__name__)

to_do = ["ikitxe bevri", "uyure kubrickis filmebs", "iswavle python"]
app.route('/')
def home():
    return render_template('index.html', to_do=to_do)

@app.route('/add_task', methods=['POST'])
def add_task():
    task = request.form['task']
    to_do.append(task)
    return redirect(url_for('home'))
    
if __name__ == '__main__':
   app.run(debug=True)

